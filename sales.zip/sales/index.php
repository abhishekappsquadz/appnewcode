
<?php include '../query_helper.php';?>
<!DOCTYPE html>
<head>
     <title>Appsquadz Hirings:: Login</title>
	 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
     <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
     <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
     <link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Montserrat:400,700" />
	
<style>
.register-form h1 {
    font-size: 30px;
    font-weight: 300;
    vertical-align: middle;
    font-family: Montserrat;
}

h1 {
    display: block;
    font-size: 2em;
    -webkit-margin-before: 0.67em;
    -webkit-margin-after: 0.67em;
    -webkit-margin-start: 0px;
    -webkit-margin-end: 0px;
    font-weight: bold;
}

.register-form {
    font-family: Montserrat;
    width: 820px;
    margin: 0 auto;
    margin-top: 5em;
    text-align: center;
    padding: 10px;
    color: #000000;
    border: solid 1px #726E6E;
	background-image:url('../img/banners/home_banner_new1aa./////jpg');
	
    border-radius: 10px;
    -webkit-border-radius: 10px;
    -moz-border-radius: 10px;
color:light-blue;
}

register-form, input {
    margin-left:50px;
}

.btn {
    display: inline-block;
    padding: 7px 29px;
    margin-bottom: 6px;
    font-size: 14px;
    font-weight: 400;
    line-height: 1.42857143;
    text-align: center;
    white-space: nowrap;
    vertical-align: middle;
    -ms-touch-action: manipulation;
    touch-action: manipulation;
    cursor: pointer;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
    background-image: none;
    border: 1px solid transparent;
    border-radius: 4px;
	margin-left:-3px;
}
label {
    <!--display: inline-block;-->
    max-width: 100%;
    margin-bottom: 5px;
    font-weight: 530;
}

</style>
</head>
<body style="background-repeat:no-repeat;" background="../img/banners/drupal/////.jpg">
    <!-- Form for logging in the users -->

    <div  class="register-form" style="display:bock">

        <img src="../img/sales/Apps_logo.png"><h1>Login Panel</h1>
        <form action="" method="POST" autocomplete="on">
            <p style="color:red; text-align: left;"></p>
            <p><label style="margin-left:-120px">User Name : </label>
            <input style="margin-left:100px" required type="text" name="username" placeholder="username" size="60%"/></p>
			
            <p><label style="margin-left:-120px">Password&nbsp;&nbsp; : </label>
             <input style="margin-left:100px" required   type="password" name="password" placeholder="password" size="60%"/></p>
            <input type ="submit" class="btn btn-primary"  name="submit" value="Login" />
        </form>
	  </div>
</body>
</html>

<?php
session_start();
if(isset($_POST['submit'])){

$uname=$_POST['username'];
$upass=$_POST['password'];
//echo($uname);
$query="select username,password from app_sales_login where username='$uname' AND password='$upass'";
$a=mysqli_query($conn,$query);
$rowcount=mysqli_num_rows($a);
//echo($rowcount);
if($rowcount>0)
{
header("location:sales_data.php");
}
else{
	echo'<div><h5  style="color:red;margin-top:-160px;margin-left:300px">Invalid Login Credentials.</h5></div>';
	}
}



?>