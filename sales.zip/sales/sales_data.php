

<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "appsquadz_main_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT * from  app_queries";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
	$ravi[]=$row;
	}
} ?>
<html>
<head>
  <title>SALES</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
<div class="container">
  <h3 style="color:teal;">SALES DATABASE</h3><br><br>           
  <table class="table table-bordered">
    <thead>
      <tr>
	   <th style="color:blue">Id</th>
        <th style="color:blue">Name</th>
		<th style="color:blue">Email</th>
        <th style="color:blue">skype_whatsapp</th>
        
      </tr>
    </thead>
	 <tbody>
<?php $i=0;foreach($ravi as $rav){ $i++; //print_r($rav['id']);die;
?>
<tr>
<td><?php echo $rav['id'];?></td>
<td><?php echo $rav['name'];?></td>
<td><?php  echo $rav['email'];?></td>
<td><?php  echo $rav['skype_whatsapp'];?></td>
</tr>
<?php }?>
</tbody>

</table>
</body>
</html>

